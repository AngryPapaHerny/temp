# Skill: Supabase Integration (Gemini Version)

HTML/JS 환경에서 Supabase를 로드하고 안전하게 연동하여 데이터를 CRUD하는 스킬입니다.

## 1. Supabase SDK 로드
Vanilla JS 환경에서는 CDN을 통해 클라이언트를 가져옵니다.
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

## 2. 초기화 및 설정
`config.js`를 별도로 두어 API Key를 주입하도록 구성합니다.
```javascript
const supabaseUrl = 'YOUR_SUPABASE_URL';
const supabaseKey = 'YOUR_SUPABASE_ANON_KEY';
const supabase = supabase.createClient(supabaseUrl, supabaseKey);
```

## 3. 데이터 패칭 (Read)
블로그 포스트 및 방명록 데이터를 안전하게 비동기로 가져옵니다.
```javascript
async function fetchPosts() {
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('Error fetching posts:', error);
    return [];
  }
  return data;
}
```

## 4. 데이터 삽입 (Create)
방명록 메시지를 데이터베이스에 추가합니다.
```javascript
async function addGuestbookMessage(username, message) {
  const { data, error } = await supabase
    .from('guestbook')
    .insert([{ username, message }]);
  
  if (error) {
    throw error;
  }
  return data;
}
```
