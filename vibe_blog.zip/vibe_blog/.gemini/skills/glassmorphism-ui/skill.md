# Skill: Glassmorphism UI & Interactions (Gemini Version)

현대적인 웹 포트폴리오를 위한 CSS 테마 설정 및 인터랙션 구현 스킬입니다.

## 1. CSS Custom Properties (Theme)
다크 모드를 기본으로 하는 HSL 기반 변수를 설정합니다.
```css
:root {
  --bg-primary: #0f172a;
  --bg-secondary: rgba(30, 41, 59, 0.7);
  --text-primary: #f8fafc;
  --text-secondary: #94a3b8;
  --accent: #a855f7; /* Violet */
  --accent-glow: rgba(168, 85, 247, 0.4);
  --border-glass: rgba(255, 255, 255, 0.08);
}
```

## 2. Glassmorphism Card Style
블러 처리와 반투명 테두리를 결합한 글래스모피즘 표준 스타일입니다.
```css
.glass-card {
  background: var(--bg-secondary);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid var(--border-glass);
  border-radius: 16px;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
}
```

## 3. Scroll Reveal Animation
스크롤 시 요소들이 서서히 나타나게 만드는 모션 효과입니다.
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('show');
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
```
```css
.reveal {
  opacity: 0;
  transform: translateY(30px);
  transition: all 0.8s ease;
}
.reveal.show {
  opacity: 1;
  transform: translateY(0);
}
```
