document.addEventListener('DOMContentLoaded', () => {
  // Lucide 아이콘 초기화
  lucide.createIcons();

  initTheme();
  initTypingEffect();
  initScrollReveal();
  initActiveNav();
  initProjectModals();
  initSupabaseAndFeatures();
});

/* ==========================================================================
   1. Theme System (Dark / Light Toggle)
   ========================================================================== */
function initTheme() {
  const themeToggleBtn = document.getElementById('theme-toggle');
  const body = document.body;
  
  // 저장된 테마 불러오기 (기본값: dark)
  const savedTheme = localStorage.getItem('theme') || 'dark';
  if (savedTheme === 'light') {
    body.classList.remove('dark-theme');
    body.classList.add('light-theme');
  } else {
    body.classList.add('dark-theme');
    body.classList.remove('light-theme');
  }

  themeToggleBtn.addEventListener('click', () => {
    if (body.classList.contains('dark-theme')) {
      body.classList.remove('dark-theme');
      body.classList.add('light-theme');
      localStorage.setItem('theme', 'light');
    } else {
      body.classList.remove('light-theme');
      body.classList.add('dark-theme');
      localStorage.setItem('theme', 'dark');
    }
  });
}

/* ==========================================================================
   2. Hero Section Typing Animation
   ========================================================================== */
function initTypingEffect() {
  const sloganElement = document.getElementById('typing-slogan');
  const words = ['Frontend Developer', '배우며 기록하는 개발자', 'Creative Thinker'];
  let wordIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typingSpeed = 100;

  function type() {
    const currentWord = words[wordIndex];
    if (isDeleting) {
      sloganElement.textContent = currentWord.substring(0, charIndex - 1);
      charIndex--;
      typingSpeed = 50;
    } else {
      sloganElement.textContent = currentWord.substring(0, charIndex + 1);
      charIndex++;
      typingSpeed = 100;
    }

    if (!isDeleting && charIndex === currentWord.length) {
      typingSpeed = 2000; // 단어 완성 후 대기 시간
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      wordIndex = (wordIndex + 1) % words.length;
      typingSpeed = 500; // 다음 단어 시작 전 대기 시간
    }

    setTimeout(type, typingSpeed);
  }

  type();
}

/* ==========================================================================
   3. Scroll Reveal Animation
   ========================================================================== */
function initScrollReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('show');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.reveal').forEach((el) => {
    observer.observe(el);
  });
}

/* ==========================================================================
   4. Active Menu Link on Scroll
   ========================================================================== */
function initActiveNav() {
  const sections = document.querySelectorAll('section');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach((section) => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      if (pageYOffset >= sectionTop - 150) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach((link) => {
      link.classList.remove('active');
      if (link.getAttribute('href').slice(1) === current) {
        link.classList.add('active');
      }
    });
  });
}

/* ==========================================================================
   5. Static Projects Modal Data & Controller
   ========================================================================== */
const PROJECTS_DATA = {
  'project-1': {
    title: 'Vibe.Blog Portfolio',
    tag: 'Frontend & DB',
    period: '2026.06 (1주일)',
    tech: 'HTML5, CSS3, Vanilla JS, Supabase',
    desc: '개발자로서의 포트폴리오와 개인의 생각을 담는 블로그를 융합한 정적 웹 페이지입니다. 다크 모드와 글래스모피즘 CSS 스타일을 기본으로 디자인되었으며, 백엔드 서버 구축 없이 Supabase SDK를 CDN으로 호출하여 방명록 작성 및 블로그 글 노출을 완벽하게 동기화했습니다.',
    solution: 'CSS Grid와 HSL 컬러 변수를 설계하여 손쉬운 테마 토글 환경을 구성했습니다. Supabase DB 연동 실패 시 사용자 경험이 저하되는 현상을 방지하고자, API 설정이 없을 시 목 데이터(Mock Data)로 자동 대체하는 방어적 로직을 추가하여 로컬 및 실서버 배포의 호환성을 높였습니다.',
    link: '#'
  },
  'project-2': {
    title: 'Syllabus AI Planner',
    tag: 'Full Stack',
    period: '2026.04 - 2026.05',
    tech: 'React, Vite, Node.js, Gemini API, Supabase',
    desc: '사용자가 학습하고자 하는 분야나 강의 목표를 입력하면, 생성형 AI(Gemini API)를 호출하여 주차별 강의 강의계획서(Syllabus)를 자동으로 제작해주는 플래너 웹 어플리케이션입니다.',
    solution: 'AI 프롬프트 엔지니어링을 구체화하여 안정적인 JSON 객체 형태로 커리큘럼을 응답받아 프론트엔드에서 파싱 오류 없이 렌더링하도록 최적화했습니다. 수립된 계획서는 Supabase 데이터베이스에 사용자 UUID별로 보관하여 언제든 이어서 학습 진척도를 기록할 수 있도록 설계했습니다.',
    link: '#'
  }
};

function initProjectModals() {
  const modal = document.getElementById('project-modal');
  const modalBody = document.getElementById('project-modal-body');
  const closeBtn = modal.querySelector('.modal-close-btn');

  document.querySelectorAll('.project-card .open-modal-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const card = e.target.closest('.project-card');
      const projectId = card.getAttribute('data-project-id');
      const project = PROJECTS_DATA[projectId];

      if (project) {
        modalBody.innerHTML = `
          <h2>${project.title}</h2>
          <div class="modal-meta">
            <span><strong>기간:</strong> ${project.period}</span>
            <span><strong>기술 스택:</strong> ${project.tech}</span>
          </div>
          <div class="modal-desc">
            <p><strong>프로젝트 개요:</strong><br>${project.desc}</p>
            <br>
            <p><strong>핵심 문제해결 및 경험:</strong><br>${project.solution}</p>
          </div>
          <div class="project-detail-grid">
            <span class="detail-label">배포 링크</span>
            <span class="detail-value"><a href="${project.link}" target="_blank" style="color: var(--accent); text-decoration: underline;">바로가기</a></span>
          </div>
        `;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  // 모달 닫기 이벤트
  const closeModal = () => {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  };
  
  closeBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
}

/* ==========================================================================
   6. Supabase Engine & Dynamic Content Rendering
   ========================================================================== */
let supabaseClient = null;

// Mock Data for Fallback
const MOCK_POSTS = [
  {
    id: 'mock-1',
    created_at: new Date().toISOString(),
    title: 'Vanilla JS만으로 고성능 다크모드/글래스모피즘 구현하기',
    summary: 'UI 프레임워크나 테일윈드 도움 없이 순수 CSS 변수와 Vanilla JS만을 활용해 브러우저 렌더링 병목을 줄이고 멋진 다크모드를 구현하는 방법.',
    content: '## Vanilla JS & CSS Variable\n\n최근 프론트엔드 생태계는 React, TailwindCSS 등의 도구들로 가득 차 있습니다. 하지만 가볍고 빠른 성능을 내야 하는 포트폴리오 정적 사이트에서는 순수 Vanilla 코딩이 훨씬 강력한 효과를 냅니다.\n\n### 테마 변경 원리\nCSS Variable을 바디 클래스에 매핑하여 스위칭하는 방식입니다.\n```css\n:root {\n  --bg-primary: #0f172a;\n}\nbody.light-theme {\n  --bg-primary: #f8fafc;\n}\n```\n이렇게 선언하면 JS에서는 단 한 줄로 모드를 바꿀 수 있습니다:\n```javascript\ndocument.body.classList.toggle("light-theme");\n```\n\n이로 인해 프레임워크 런타임 오버헤드가 없고 브라우저 하드웨어 가속이 최대로 적용됩니다.',
    tags: ['Tech', 'CSS', 'VanillaJS']
  },
  {
    id: 'mock-2',
    created_at: new Date(Date.now() - 86400000).toISOString(),
    title: '나만의 사이드 프로젝트를 시작하기 전에 고려해야 할 3가지',
    summary: '아이디어 구상부터 실 사용자 배포까지, 사이드 프로젝트의 시작과 완성을 결정하는 핵심 체크리스트 요약.',
    content: '## 사이드 프로젝트 완성을 위한 마인드셋\n\n많은 개발자들이 사이드 프로젝트를 호기롭게 시작하지만, 끝을 맺지 못하는 경우가 많습니다. 다음 3가지를 명확히 설계하세요.\n\n### 1. 목표 범위 최소화 (MVP)\n가장 중요한 기능 1가지만을 완성하는 것을 목표로 설정해야 합니다.\n\n### 2. 친근한 도구 선택\n공부 목적이 아니라 완성이 목표라면 이미 손에 익은 편리한 도구(예: Supabase)를 통해 배포 시간을 극단적으로 단축해야 합니다.\n\n### 3. 피드백 루프 만들기\n단 1명의 실 사용자가 주는 피드백이 프로젝트를 지속해 나가는 강력한 원동력이 됩니다.',
    tags: ['Life', 'Ideas']
  }
];

const MOCK_GUESTBOOK = [
  { id: 1, created_at: new Date().toISOString(), username: '테스터', message: '방명록 기능이 아주 부드럽고 예쁘네요! 대박나세요.' },
  { id: 2, created_at: new Date(Date.now() - 120000).toISOString(), username: '인사봇', message: '안녕하세요! 포트폴리오 구경 잘 하고 갑니다. 멋진 개발자로 거듭나시길!' }
];

async function initSupabaseAndFeatures() {
  const blogContainer = document.getElementById('blog-posts-container');
  const guestbookContainer = document.getElementById('guestbook-messages-container');

  // Supabase 설정 확인 및 초기화
  const hasConfig = SUPABASE_CONFIG.URL && SUPABASE_CONFIG.ANON_KEY;
  
  if (hasConfig) {
    try {
      supabaseClient = supabase.createClient(SUPABASE_CONFIG.URL, SUPABASE_CONFIG.ANON_KEY);
      console.log('Supabase initialized successfully.');
    } catch (e) {
      console.error('Failed to initialize Supabase client:', e);
    }
  }

  // 데이터 로딩 진행
  await loadBlogPosts(blogContainer, hasConfig);
  await loadGuestbook(guestbookContainer, hasConfig);
  setupGuestbookForm(guestbookContainer, hasConfig);
}

/* Blog Posts Loader */
async function loadBlogPosts(container, hasConfig) {
  let posts = [];
  
  if (hasConfig && supabaseClient) {
    try {
      const { data, error } = await supabaseClient
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!error && data && data.length > 0) {
        posts = data;
      } else {
        if (error) console.error('Supabase fetch posts error:', error);
        posts = MOCK_POSTS; // fallback
      }
    } catch (err) {
      console.error('Supabase query error:', err);
      posts = MOCK_POSTS;
    }
  } else {
    // API 설정이 없으므로 Mock 데이터 활용
    posts = MOCK_POSTS;
  }

  container.innerHTML = '';
  posts.forEach(post => {
    const card = document.createElement('div');
    card.className = 'blog-card glass-card';
    card.innerHTML = `
      <div class="blog-meta">
        <span><i data-lucide="calendar" style="width: 14px; height: 14px; display: inline; vertical-align: text-bottom;"></i> ${new Date(post.created_at).toLocaleDateString()}</span>
      </div>
      <h3>${post.title}</h3>
      <p class="blog-summary">${post.summary}</p>
      <div class="blog-tags">
        ${post.tags ? post.tags.map(tag => `<span class="blog-tag">#${tag}</span>`).join('') : ''}
      </div>
      <span class="read-more" data-post-id="${post.id}">더 읽어보기 <i data-lucide="arrow-up-right" style="width: 16px; height: 16px;"></i></span>
    `;
    container.appendChild(card);
  });
  
  // Lucide 아이콘 새로 적용
  lucide.createIcons();
  
  // 블로그 상세 보기 모달 이벤트 바인딩
  const blogModal = document.getElementById('blog-modal');
  const blogModalBody = document.getElementById('blog-modal-body');
  const closeBtn = blogModal.querySelector('.modal-close-btn');

  container.querySelectorAll('.read-more').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const postId = e.target.getAttribute('data-post-id');
      const post = posts.find(p => p.id === postId);
      if (post) {
        // 간단한 Markdown -> HTML 변환 (보여주기용)
        let formattedContent = post.content
          .replace(/^## (.*$)/gim, '<h2>$1</h2>')
          .replace(/^### (.*$)/gim, '<h3>$1</h3>')
          .replace(/```javascript([\s\S]*?)```/gim, '<pre><code>$1</code></pre>')
          .replace(/```css([\s\S]*?)```/gim, '<pre><code>$1</code></pre>')
          .replace(/\n/g, '<br>');

        blogModalBody.innerHTML = `
          <h2>${post.title}</h2>
          <div class="modal-meta">
            <span>작성일: ${new Date(post.created_at).toLocaleString()}</span>
          </div>
          <div class="modal-desc" style="max-height: 60vh; overflow-y: auto;">
            ${formattedContent}
          </div>
        `;
        blogModal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  const closeBlogModal = () => {
    blogModal.classList.remove('active');
    document.body.style.overflow = '';
  };
  closeBtn.addEventListener('click', closeBlogModal);
  blogModal.addEventListener('click', (e) => {
    if (e.target === blogModal) closeBlogModal();
  });
}

/* Guestbook Messages Loader */
async function loadGuestbook(container, hasConfig) {
  let messages = [];

  if (hasConfig && supabaseClient) {
    try {
      const { data, error } = await supabaseClient
        .from('guestbook')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!error && data) {
        messages = data;
      } else {
        if (error) console.error('Supabase fetch guestbook error:', error);
        messages = MOCK_GUESTBOOK;
      }
    } catch (err) {
      console.error('Supabase guestbook query error:', err);
      messages = MOCK_GUESTBOOK;
    }
  } else {
    messages = MOCK_GUESTBOOK;
  }

  container.innerHTML = '';
  if (messages.length === 0) {
    container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px 0;">남겨진 메시지가 없습니다. 첫 마디를 적어보세요!</p>';
    return;
  }

  messages.forEach(msg => {
    const item = document.createElement('div');
    item.className = 'guestbook-item';
    item.innerHTML = `
      <div class="gb-meta">
        <span class="gb-author">${escapeHTML(msg.username)}</span>
        <span class="gb-date">${new Date(msg.created_at).toLocaleString()}</span>
      </div>
      <div class="gb-content">${escapeHTML(msg.message)}</div>
    `;
    container.appendChild(item);
  });
}

/* Guestbook Form Controller */
function setupGuestbookForm(container, hasConfig) {
  const form = document.getElementById('guestbook-form');
  const submitBtn = document.getElementById('gb-submit-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const nameInput = document.getElementById('gb-name');
    const msgInput = document.getElementById('gb-message');
    
    const username = nameInput.value.trim();
    const message = msgInput.value.trim();

    if (!username || !message) return;

    // UI 비활성화
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>등록 중...</span><div class="spinner" style="width: 14px; height: 14px; border-width: 2px; margin: 0;"></div>';

    if (hasConfig && supabaseClient) {
      try {
        const { error } = await supabaseClient
          .from('guestbook')
          .insert([{ username, message }]);
        
        if (error) throw error;
        
        // 입력 폼 비우기
        msgInput.value = '';
        await loadGuestbook(container, hasConfig);
      } catch (err) {
        alert('방명록 등록에 실패했습니다: ' + err.message);
      }
    } else {
      // 로컬 테스트(Mock) 모드일 경우 임시 배열에 삽입 후 렌더링
      const newMockMsg = {
        id: Date.now(),
        created_at: new Date().toISOString(),
        username: username,
        message: message
      };
      MOCK_GUESTBOOK.unshift(newMockMsg);
      msgInput.value = '';
      await loadGuestbook(container, hasConfig);
      
      // 사용자에게 로컬 목(Mock) 추가 상태임을 작게 노출
      console.log('Mock guestbook entry added.');
    }

    // UI 복구
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<span>남기기</span><i data-lucide="send"></i>';
    lucide.createIcons();
  });
}

/* Helper function to prevent XSS */
function escapeHTML(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
