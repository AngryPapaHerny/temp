/**
 * Supabase Configuration
 * 
 * [설정 방법]
 * 1. https://supabase.com 에 가입 후 새 프로젝트를 만듭니다.
 * 2. 프로젝트의 [Project Settings] -> [API] 메뉴로 이동합니다.
 * 3. 'Project URL'과 'anon public' API Key를 확인합니다.
 * 4. 아래 변수 값에 해당 값들을 입력해주세요.
 * 
 * [보안 안내]
 * - 이 포트폴리오를 GitHub 등 공개 저장소에 업로드할 때, anon key는 프론트엔드에 노출되어도 괜찮은 Public 키입니다.
 * - 하지만 Supabase Database에서 RLS(Row Level Security) 설정이 활성화되어 있어야 악성 사용자의 무단 수정/삭제를 막을 수 있습니다.
 * - .gemini/skills/supabase-integration/skill.md 가이드에 따라 테이블 RLS를 반드시 활성화해주세요.
 */

const SUPABASE_CONFIG = {
  // 본인의 Supabase 프로젝트 URL을 입력하세요. (예: 'https://xyz.supabase.co')
  URL: '',
  
  // 본인의 Supabase anon public key를 입력하세요.
  ANON_KEY: ''
};
